// VerticalTabs - Service Worker
// Opens the side panel when the extension icon is clicked.

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
